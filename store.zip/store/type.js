export const SET_CURRENT_USER = 'SET_CURRENT_USER';
export const CLEAR_CURRENT_USER = 'CLEAR_CURRENT_USER';
export const ADD_CART='ADD_CART';
export const REMOVE_CART='REMOVE_CART';
export const PLUS_CART='PLUS_CART';
export const MINUS_CART='MINUS_CART';