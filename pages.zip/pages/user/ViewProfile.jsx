import React from 'react'

const ViewProfile = () => {
  return (
    <div>
      <h1>View Profile</h1>
    </div>
  )
}

export default ViewProfile;
