const NotFound = () => {
  return <h1>Not found</h1>;
};

export { NotFound };
